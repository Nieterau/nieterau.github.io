In the src file you can see the java files with the source code. 
Only the main and view folder contain files.
It also contains the JAR file to see how the application should work.
